Use linux system

makefile attached to recompile and rebuild

3 sub testfile provided
hello.txt
script.txt
test.txt

1 main testfile provided
testfile.txt

use testfile.txt to test the program, if any error comes up try to execute the makefile again (the make file is totally working on my server side)