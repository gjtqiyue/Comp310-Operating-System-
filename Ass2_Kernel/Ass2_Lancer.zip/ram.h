int addToRam(FILE *fp);
void deleteFromRam(int index);