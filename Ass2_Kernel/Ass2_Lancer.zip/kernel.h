int myInit(FILE *fp);
int scheduler();