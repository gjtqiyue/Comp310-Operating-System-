int memoryset(char *var, char *string);
const char * memoryget(char *var);