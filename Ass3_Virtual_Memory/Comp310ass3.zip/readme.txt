Use linux system

makefile attached to recompile and rebuild

Note: all the txt file in backing store will be deleted after the exec command, but the directory will remain and only get recreated in boot(). If you want to see the actual file creation and deletion then you have to modify the code or use debug tool to see it when it's running.

2 main testfile provided
test1.txt
test2.txt

use testfile.txt to test the program, if any error comes up try to execute the makefile again (the make file is totally working on my server side)